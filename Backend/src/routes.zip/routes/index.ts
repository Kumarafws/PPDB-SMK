import { Router } from "express"
import { authRouter } from "./auth.js"
import { studentsRouter } from "./students.js"
import { documentsRouter } from "./documents.js"
import { settingsRouter } from "./settings.js"
import { adminRouter } from "./admin.js"
import { profilesRouter } from "./profiles.js"

/**
 * Ringkasan API (siap integrasi frontend, base path `/api`):
 *
 * - POST /auth/register | /auth/login | GET /auth/me
 * - GET|PATCH /students/me | dokumen: GET|POST /students/me/documents, DELETE .../me/documents/:id
 * - GET /students | GET|PATCH /students/:id | GET /students/:id/documents (admin/superadmin)
 * - PATCH /documents/:id (verifikasi/tolak dokumen, admin)
 * - GET /settings | GET /settings/key/:key | PUT /settings/key/:key (superadmin)
 * - GET|POST /admin/logs
 * - GET /profiles | PATCH /profiles/:id/role | DELETE /profiles/:id (superadmin)
 *
 * Header: Authorization: Bearer <access_token>
 * JSON siswa memakai snake_case agar selaras dengan tipe `Student` / `Document` di frontend.
 */
export const apiRouter = Router()

apiRouter.get("/", (_req, res) => {
  res.json({
    name: "PPDB API",
    version: "0.2.0",
    docs: "Lihat komentar di routes/index.ts",
  })
})

apiRouter.use("/auth", authRouter)
apiRouter.use("/students", studentsRouter)
apiRouter.use("/documents", documentsRouter)
apiRouter.use("/settings", settingsRouter)
apiRouter.use("/admin", adminRouter)
apiRouter.use("/profiles", profilesRouter)
